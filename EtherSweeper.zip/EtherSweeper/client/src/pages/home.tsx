import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { SecurityWarning } from "@/components/SecurityWarning";
import { WalletScanner } from "@/components/WalletScanner";
import { NetworkStatus } from "@/components/NetworkStatus";
import { AssetList } from "@/components/AssetList";
import { ExecutionPanel } from "@/components/ExecutionPanel";
import { TransactionHistory } from "@/components/TransactionHistory";
import { UseAdvancedFeatures } from "@/components/UseAdvancedFeatures";
import { AdvancedFeatures } from "@/components/AdvancedFeatures";
import { BlockchainStatus } from "@/components/BlockchainStatus";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [currentScanId, setCurrentScanId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get recent transactions
  const { data: recentTransactions = [] } = useQuery({
    queryKey: ["/api/transactions/recent"],
    refetchInterval: 5000,
  });

  // Get current scan details
  const { data: currentScan, isLoading: scanLoading } = useQuery({
    queryKey: ["/api/wallet-scans", currentScanId],
    enabled: !!currentScanId,
    refetchInterval: 2000,
  });

  // Get network status
  const { data: networkStatus = [] } = useQuery({
    queryKey: ["/api/wallet-scans", currentScanId, "networks"],
    enabled: !!currentScanId,
    refetchInterval: 2000,
  });

  // Get detected assets
  const { data: detectedAssets = [] } = useQuery({
    queryKey: ["/api/wallet-scans", currentScanId, "assets"],
    enabled: !!currentScanId,
    refetchInterval: 3000,
  });

  // Create wallet scan mutation
  const createScanMutation = useMutation({
    mutationFn: async (data: { sourceAddress: string; destinationAddress: string }) => {
      const response = await apiRequest("POST", "/api/wallet-scans", data);
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentScanId(data.id);
      toast({
        title: "Scan Started",
        description: "Scanning all networks for assets...",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet-scans"] });
    },
    onError: () => {
      toast({
        title: "Scan Failed",
        description: "Failed to start wallet scan. Please check your inputs.",
        variant: "destructive",
      });
    },
  });

  // Execute sweep mutation
  const executeSweepMutation = useMutation({
    mutationFn: async (data: { 
      privateKey: string; 
      enableMevProtection: boolean; 
      priorityGas: boolean 
    }) => {
      const response = await apiRequest("POST", `/api/wallet-scans/${currentScanId}/execute`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Execution Started",
        description: "Multi-network sweep initiated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet-scans", currentScanId] });
    },
    onError: () => {
      toast({
        title: "Execution Failed",
        description: "Failed to execute sweep. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartScan = (sourceAddress: string, destinationAddress: string) => {
    createScanMutation.mutate({ sourceAddress, destinationAddress });
  };

  const handleExecuteSweep = (privateKey: string, options: { enableMevProtection: boolean; priorityGas: boolean }) => {
    executeSweepMutation.mutate({ 
      privateKey, 
      enableMevProtection: options.enableMevProtection,
      priorityGas: options.priorityGas
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <i className="fas fa-wallet text-crypto-green text-2xl"></i>
            <h1 className="text-xl font-bold">Multi-Network Wallet Sweeper</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="bg-green-900/20 border border-green-700 px-3 py-1 rounded-full">
              <span className="text-green-400 text-sm font-medium">
                <i className="fas fa-shield-halved mr-1"></i>
                Secure Session
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <SecurityWarning />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Input and Status */}
          <div className="lg:col-span-2 space-y-6">
            <WalletScanner
              onStartScan={handleStartScan}
              isLoading={createScanMutation.isPending}
            />

            <NetworkStatus 
              networks={networkStatus as any[]}
              isScanning={(currentScan as any)?.status === "scanning"}
            />

            {(currentScan as any)?.detectedAssets && (
              <AssetList 
                assets={(currentScan as any).detectedAssets}
                isLoading={scanLoading}
              />
            )}

            <AdvancedFeatures 
              walletAddress={(currentScan as any)?.walletAddress}
              walletScanId={currentScanId || undefined}
            />
          </div>

          {/* Right Column - Execution */}
          <div className="space-y-6">
            <BlockchainStatus />
            
            <ExecutionPanel
              scanId={currentScanId}
              assets={detectedAssets as any[]}
              onExecuteSweep={handleExecuteSweep}
              isExecuting={executeSweepMutation.isPending}
              currentScan={currentScan}
            />
          </div>
        </div>

        <TransactionHistory transactions={recentTransactions as any[]} />
      </main>
    </div>
  );
}