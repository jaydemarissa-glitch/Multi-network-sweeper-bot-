
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowRightLeft, 
  Coins, 
  Vote, 
  Image, 
  Bot, 
  TrendingUp, 
  Clock, 
  Zap,
  AlertTriangle
} from "lucide-react";

interface AdvancedFeaturesProps {
  walletAddress?: string;
  walletScanId?: string;
}

export function AdvancedFeatures({ walletAddress, walletScanId }: AdvancedFeaturesProps) {
  const [selectedFeature, setSelectedFeature] = useState<string>("bridge");

  // Fetch data for each feature
  const { data: yieldPositions } = useQuery({
    queryKey: ["/api/yield-farming", walletAddress],
    enabled: !!walletAddress,
  });

  const { data: governanceClaims } = useQuery({
    queryKey: ["/api/governance/claims", walletAddress],
    enabled: !!walletAddress,
  });

  const { data: nftData } = useQuery({
    queryKey: ["/api/nfts", walletAddress],
    enabled: !!walletAddress,
  });

  const { data: arbitrageOps } = useQuery({
    queryKey: ["/api/ai/arbitrage"],
    enabled: !!walletScanId,
  });

  const { data: marketConditions } = useQuery({
    queryKey: ["/api/ai/market-conditions", "1"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Bot className="w-5 h-5 text-purple-400" />
          <span>Advanced Features</span>
          <Badge variant="outline" className="text-purple-400 border-purple-400">
            AI-Powered
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedFeature} onValueChange={setSelectedFeature}>
          <TabsList className="grid grid-cols-5 mb-6">
            <TabsTrigger value="bridge" className="flex items-center space-x-1">
              <ArrowRightLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Bridge</span>
            </TabsTrigger>
            <TabsTrigger value="yield" className="flex items-center space-x-1">
              <Coins className="w-4 h-4" />
              <span className="hidden sm:inline">Yield</span>
            </TabsTrigger>
            <TabsTrigger value="governance" className="flex items-center space-x-1">
              <Vote className="w-4 h-4" />
              <span className="hidden sm:inline">Gov</span>
            </TabsTrigger>
            <TabsTrigger value="nft" className="flex items-center space-x-1">
              <Image className="w-4 h-4" />
              <span className="hidden sm:inline">NFT</span>
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center space-x-1">
              <Bot className="w-4 h-4" />
              <span className="hidden sm:inline">AI</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="bridge" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Cross-Chain Bridge</h3>
              <Badge className="bg-blue-900 text-blue-200">
                Consolidate Assets
              </Badge>
            </div>
            <p className="text-slate-400 text-sm">
              Automatically bridge assets from all networks to your preferred chain for unified management.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-800 p-3 rounded-lg">
                <div className="text-xs text-slate-400">Supported Bridges</div>
                <div className="text-sm font-medium">Stargate, LayerZero, Hop</div>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg">
                <div className="text-xs text-slate-400">Estimated Savings</div>
                <div className="text-sm font-medium text-green-400">15-25% vs manual</div>
              </div>
            </div>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              <ArrowRightLeft className="w-4 h-4 mr-2" />
              Configure Bridge Settings
            </Button>
          </TabsContent>

          <TabsContent value="yield" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Yield Farming Extraction</h3>
              <Badge className="bg-green-900 text-green-200">
                {yieldPositions?.length || 0} Positions Found
              </Badge>
            </div>
            <p className="text-slate-400 text-sm">
              Detect and extract value from yield farming positions across all supported protocols.
            </p>
            <div className="space-y-2">
              {yieldPositions?.slice(0, 3).map((position: any, index: number) => (
                <div key={index} className="bg-slate-800 p-3 rounded-lg flex justify-between items-center">
                  <div>
                    <div className="font-medium">{position.protocol}</div>
                    <div className="text-sm text-slate-400">{position.poolName}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{position.stakedAmount}</div>
                    <div className="text-sm text-green-400">{position.apy} APY</div>
                  </div>
                </div>
              ))}
            </div>
            <Button className="w-full bg-green-600 hover:bg-green-700">
              <Coins className="w-4 h-4 mr-2" />
              Harvest All Rewards
            </Button>
          </TabsContent>

          <TabsContent value="governance" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Governance Claims</h3>
              <Badge className="bg-purple-900 text-purple-200">
                ${governanceClaims?.totalValue || "0"} Available
              </Badge>
            </div>
            <p className="text-slate-400 text-sm">
              Automatically claim unclaimed governance tokens from DeFi protocols across all networks.
            </p>
            <div className="space-y-2">
              {governanceClaims?.claims?.slice(0, 3).map((claim: any, index: number) => (
                <div key={index} className="bg-slate-800 p-3 rounded-lg flex justify-between items-center">
                  <div>
                    <div className="font-medium">{claim.protocol}</div>
                    <div className="text-sm text-slate-400">{claim.tokenSymbol}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{claim.claimableAmount}</div>
                    {claim.claimDeadline && (
                      <div className="text-sm text-orange-400">
                        <Clock className="w-3 h-3 inline mr-1" />
                        Expires soon
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <Button className="w-full bg-purple-600 hover:bg-purple-700">
              <Vote className="w-4 h-4 mr-2" />
              Claim All Tokens
            </Button>
          </TabsContent>

          <TabsContent value="nft" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">NFT Liquidation</h3>
              <Badge className="bg-pink-900 text-pink-200">
                {nftData?.nfts?.length || 0} NFTs Found
              </Badge>
            </div>
            <p className="text-slate-400 text-sm">
              Detect NFTs across multiple chains and create optimized liquidation strategies.
            </p>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-slate-800 p-3 rounded-lg text-center">
                <div className="text-xs text-slate-400">Floor Value</div>
                <div className="text-sm font-medium">{nftData?.liquidationValue?.total || "0"} ETH</div>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg text-center">
                <div className="text-xs text-slate-400">Quick Sale</div>
                <div className="text-sm font-medium text-orange-400">{nftData?.liquidationValue?.quick || "0"} ETH</div>
              </div>
              <div className="bg-slate-800 p-3 rounded-lg text-center">
                <div className="text-xs text-slate-400">Patient Sale</div>
                <div className="text-sm font-medium text-green-400">{nftData?.liquidationValue?.patient || "0"} ETH</div>
              </div>
            </div>
            <Button className="w-full bg-pink-600 hover:bg-pink-700">
              <Image className="w-4 h-4 mr-2" />
              Create Liquidation Plan
            </Button>
          </TabsContent>

          <TabsContent value="ai" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">AI Optimization</h3>
              <Badge className="bg-cyan-900 text-cyan-200">
                Real-time Analysis
              </Badge>
            </div>
            <p className="text-slate-400 text-sm">
              AI-powered timing optimization and arbitrage detection for maximum efficiency.
            </p>
            
            {/* Market Conditions */}
            <div className="bg-slate-800 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Current Market Conditions</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-slate-400">Gas Price</div>
                  <div className="text-sm font-medium">{marketConditions?.gasPrice || "0"} gwei</div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Recommendation</div>
                  <Badge variant={marketConditions?.recommendedAction === 'execute' ? 'default' : 'secondary'}>
                    {marketConditions?.recommendedAction || 'loading'}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Arbitrage Opportunities */}
            <div className="bg-slate-800 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Arbitrage Opportunities</h4>
              {arbitrageOps?.slice(0, 2).map((op: any, index: number) => (
                <div key={index} className="flex justify-between items-center py-2">
                  <div>
                    <div className="text-sm font-medium">{op.tokenSymbol}</div>
                    <div className="text-xs text-slate-400">{op.buyExchange} → {op.sellExchange}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-green-400">+{op.profitPercent}%</div>
                    <div className="text-xs text-slate-400">{op.timeWindow}s window</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" className="border-cyan-600 text-cyan-400">
                <TrendingUp className="w-4 h-4 mr-2" />
                Optimize Timing
              </Button>
              <Button variant="outline" className="border-cyan-600 text-cyan-400">
                <Zap className="w-4 h-4 mr-2" />
                Execute Arbitrage
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {/* Warning */}
        <div className="mt-6 p-4 bg-orange-900/20 border border-orange-700 rounded-lg">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-orange-400 mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <p className="text-orange-400 font-medium">Advanced Features Notice</p>
              <p className="text-orange-300 mt-1">
                These features involve complex DeFi operations. Ensure you understand the risks and have sufficient gas funds for execution.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
