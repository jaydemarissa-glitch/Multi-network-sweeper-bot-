import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Clock, RefreshCw } from "lucide-react";

interface NetworkHealth {
  name: string;
  chainId: string;
  status: string;
  blockNumber?: string;
  actualChainId?: string;
  rpcUrl?: string;
  error?: string;
}

interface BlockchainHealthResponse {
  timestamp: string;
  networks: NetworkHealth[];
}

export function BlockchainStatus() {
  const { data: healthData, isLoading, error, refetch } = useQuery<BlockchainHealthResponse>({
    queryKey: ["/api/blockchain/health"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case "error":
        return <XCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return <Badge className="bg-green-900 text-green-200">Connected</Badge>;
      case "error":
        return <Badge className="bg-red-900 text-red-200">Error</Badge>;
      default:
        return <Badge className="bg-yellow-900 text-yellow-200">Initializing</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <RefreshCw className="w-5 h-5 text-blue-400 animate-spin" />
            <span>Checking Blockchain Connections...</span>
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <XCircle className="w-5 h-5 text-red-400" />
            <span>Connection Check Failed</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400 text-sm">
            Unable to check blockchain connections. Please verify your API configuration.
          </p>
        </CardContent>
      </Card>
    );
  }

  const connectedNetworks = healthData?.networks?.filter(n => n.status === "connected") || [];
  const totalNetworks = healthData?.networks?.length || 0;

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span>Blockchain Networks</span>
          </div>
          <Badge className="bg-blue-900 text-blue-200">
            {connectedNetworks.length}/{totalNetworks} Connected
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {healthData?.networks?.map((network) => (
            <div
              key={network.chainId}
              className="flex items-center justify-between p-3 bg-slate-800 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                {getStatusIcon(network.status)}
                <div>
                  <div className="font-medium">{network.name}</div>
                  <div className="text-sm text-slate-400">
                    Chain ID: {network.chainId}
                    {network.blockNumber && (
                      <span className="ml-2">Block: {network.blockNumber}</span>
                    )}
                  </div>
                  {network.error && (
                    <div className="text-xs text-red-400 mt-1">
                      {network.error}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {network.rpcUrl && (
                  <Badge variant="outline" className="text-xs">
                    {network.rpcUrl}
                  </Badge>
                )}
                {getStatusBadge(network.status)}
              </div>
            </div>
          ))}
        </div>
        
        {healthData?.timestamp && (
          <div className="mt-4 pt-3 border-t border-slate-700">
            <p className="text-xs text-slate-500">
              Last checked: {new Date(healthData.timestamp).toLocaleTimeString()}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}