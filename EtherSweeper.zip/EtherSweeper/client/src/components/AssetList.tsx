import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Coins, Lock, Zap, Clock } from "lucide-react";

interface DetectedAsset {
  id: string;
  networkName: string;
  tokenSymbol: string;
  tokenName: string;
  balance: string;
  valueUsd: string | null;
  assetType: string;
  stakingProtocol: string | null;
  isStaked: boolean;
}

interface AssetListProps {
  assets: DetectedAsset[];
  totalValue?: string | null;
  isLoading: boolean;
}

export function AssetList({ assets, totalValue, isLoading }: AssetListProps) {
  const getAssetIcon = (tokenSymbol: string, assetType: string) => {
    if (assetType === "staked") {
      return <Lock className="w-6 h-6 text-amber-400" />;
    }
    
    switch (tokenSymbol) {
      case "ETH":
        return <i className="fab fa-ethereum text-blue-400 text-xl"></i>;
      case "BNB":
        return <i className="fas fa-coins text-yellow-400 text-xl"></i>;
      case "MATIC":
        return <i className="fas fa-layer-group text-purple-400 text-xl"></i>;
      case "USDC":
      case "USDT":
        return <i className="fas fa-dollar-sign text-green-400 text-xl"></i>;
      default:
        return <Coins className="w-6 h-6 text-slate-400" />;
    }
  };

  const getAssetBadge = (asset: DetectedAsset) => {
    if (asset.isStaked) {
      return (
        <Badge variant="outline" className="border-amber-600 text-amber-400">
          <Clock className="w-3 h-3 mr-1" />
          {asset.stakingProtocol || "Staked"}
        </Badge>
      );
    }
    
    if (asset.assetType === "native") {
      return (
        <Badge variant="outline" className="border-blue-600 text-blue-400">
          Native
        </Badge>
      );
    }
    
    return (
      <Badge variant="outline" className="border-slate-600 text-slate-400">
        ERC-20
      </Badge>
    );
  };

  const formatBalance = (balance: string, symbol: string) => {
    const num = parseFloat(balance);
    if (num === 0) return "0";
    if (num < 0.000001) return "< 0.000001";
    return `${num.toFixed(6)} ${symbol}`;
  };

  const formatValue = (valueUsd: string | null) => {
    if (!valueUsd) return "$ --";
    const value = parseFloat(valueUsd);
    return `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold flex items-center">
              <Coins className="text-crypto-green mr-2" />
              Detected Assets
            </h3>
            <Skeleton className="h-6 w-24 bg-slate-800" />
          </div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-16 w-full bg-slate-800" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center">
            <Coins className="text-crypto-green mr-2" />
            Detected Assets
          </h3>
          {totalValue && (
            <span className="text-sm text-slate-400">
              Total Value: <span className="text-crypto-green font-medium">{formatValue(totalValue)}</span>
            </span>
          )}
        </div>

        {assets.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <Coins className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No assets detected yet</p>
            <p className="text-sm">Start a scan to discover assets across all networks</p>
          </div>
        ) : (
          <div className="space-y-3">
            {assets.map((asset) => (
              <div 
                key={asset.id} 
                className={`flex items-center justify-between p-4 bg-slate-800 rounded-lg border ${
                  asset.isStaked ? 'border-amber-600' : 'border-slate-600'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0">
                    {getAssetIcon(asset.tokenSymbol, asset.assetType)}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{asset.tokenName}</span>
                      {getAssetBadge(asset)}
                    </div>
                    <div className="text-sm text-slate-400 flex items-center space-x-2">
                      <span>{asset.networkName}</span>
                      {asset.stakingProtocol && (
                        <>
                          <span>•</span>
                          <span className="text-amber-400">{asset.stakingProtocol}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">{formatBalance(asset.balance, asset.tokenSymbol)}</div>
                  <div className="text-sm text-slate-400">{formatValue(asset.valueUsd)}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
