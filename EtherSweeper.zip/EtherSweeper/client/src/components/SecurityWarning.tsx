import { AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export function SecurityWarning() {
  return (
    <Card className="bg-red-900/20 border-red-700 mb-8">
      <CardContent className="p-6">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="text-red-400 text-xl mt-1 flex-shrink-0" />
          <div>
            <h2 className="text-red-400 font-bold text-lg mb-2">Critical Security Warning</h2>
            <ul className="text-red-300 space-y-1 text-sm">
              <li>• Never enter private keys on untrusted devices or networks</li>
              <li>• Ensure you are the legitimate owner of all wallets being swept</li>
              <li>• This tool will transfer ALL assets from source wallets to the destination</li>
              <li>• Review all transaction details before executing</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
