import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Eye, EyeOff, Key, Search, Info } from "lucide-react";

const walletScanSchema = z.object({
  sourceAddress: z.string().min(42, "Invalid wallet address").regex(/^0x[a-fA-F0-9]{40}$/, "Invalid Ethereum address format"),
  destinationAddress: z.string().min(42, "Invalid wallet address").regex(/^0x[a-fA-F0-9]{40}$/, "Invalid Ethereum address format"),
  privateKey: z.string().min(64, "Invalid private key").regex(/^(0x)?[a-fA-F0-9]{64}$/, "Invalid private key format"),
});

type WalletScanForm = z.infer<typeof walletScanSchema>;

interface WalletScannerProps {
  onStartScan: (sourceAddress: string, destinationAddress: string) => void;
  isLoading: boolean;
}

export function WalletScanner({ onStartScan, isLoading }: WalletScannerProps) {
  const [showPrivateKey, setShowPrivateKey] = useState(false);

  const form = useForm<WalletScanForm>({
    resolver: zodResolver(walletScanSchema),
    defaultValues: {
      sourceAddress: "",
      destinationAddress: "",
      privateKey: "",
    },
  });

  const onSubmit = (data: WalletScanForm) => {
    // Store private key in component state for later use during execution
    onStartScan(data.sourceAddress, data.destinationAddress);
  };

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Key className="text-crypto-green mr-2" />
          Wallet Configuration
        </h3>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="sourceAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">
                    Source Wallet Address
                    <span className="text-red-400 ml-1">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="0x..."
                      className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-500 focus:border-crypto-green focus:ring-crypto-green"
                    />
                  </FormControl>
                  <div className="flex items-center text-xs text-slate-400 mt-1">
                    <Info className="w-3 h-3 mr-1" />
                    Will scan all EVM networks for this wallet
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="privateKey"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">
                    Source Wallet Private Key
                    <span className="text-red-400 ml-1">*</span>
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type={showPrivateKey ? "text" : "password"}
                        placeholder="0x..."
                        className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-500 focus:border-crypto-green focus:ring-crypto-green pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-200"
                        onClick={() => setShowPrivateKey(!showPrivateKey)}
                      >
                        {showPrivateKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </FormControl>
                  <div className="flex items-center text-xs text-slate-400 mt-1">
                    <Info className="w-3 h-3 mr-1" />
                    Required for transaction signing
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="destinationAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">
                    Destination Wallet Address
                    <span className="text-red-400 ml-1">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="0x..."
                      className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-500 focus:border-crypto-green focus:ring-crypto-green"
                    />
                  </FormControl>
                  <div className="flex items-center text-xs text-slate-400 mt-1">
                    <Info className="w-3 h-3 mr-1" />
                    All assets will be converted to USDT and sent here
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-crypto-green hover:bg-crypto-green-dark text-white font-semibold py-3 transition-colors"
            >
              {isLoading ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Scanning Networks...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Search className="w-4 h-4" />
                  <span>Scan All Networks</span>
                </div>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
