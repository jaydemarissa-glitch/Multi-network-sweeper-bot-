import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  CheckCircle, 
  Clock, 
  Pause, 
  Rocket, 
  Shield, 
  Bot, 
  ListChecks,
  Route,
  Zap
} from "lucide-react";

interface ExecutionPanelProps {
  scanId: string | null;
  assets: any[];
  onExecuteSweep: (privateKey: string, options: { enableMevProtection: boolean; priorityGas: boolean }) => void;
  isExecuting: boolean;
  currentScan: any;
}

export function ExecutionPanel({ 
  scanId, 
  assets, 
  onExecuteSweep, 
  isExecuting, 
  currentScan 
}: ExecutionPanelProps) {
  const [enableMevProtection, setEnableMevProtection] = useState(true);
  const [priorityGas, setPriorityGas] = useState(true);

  // Get unstaking plan
  const { data: unstakingPlan = [] } = useQuery({
    queryKey: ["/api/wallet-scans", scanId, "unstaking-plan"],
    enabled: !!scanId && assets.length > 0,
  });

  const stakedAssets = assets.filter(asset => asset.isStaked);
  const liquidAssets = assets.filter(asset => !asset.isStaked);
  const totalAssets = assets.length;
  const estimatedGas = "0.047";
  const finalUsdtAmount = currentScan?.finalUsdtAmount || "12,799.47";

  const executionSteps = [
    {
      id: 1,
      title: "Unstake Positions",
      description: "Begin unstaking from Lido & PancakeSwap",
      status: stakedAssets.length > 0 ? (isExecuting ? "active" : "pending") : "skipped",
      icon: <Clock className="w-4 h-4" />
    },
    {
      id: 2,
      title: "Sweep Liquid Assets", 
      description: "Transfer ETH, USDC to destination",
      status: "pending",
      icon: <Pause className="w-4 h-4" />
    },
    {
      id: 3,
      title: "Convert to USDT",
      description: "Exchange all tokens for USDT",
      status: "pending", 
      icon: <Pause className="w-4 h-4" />
    },
    {
      id: 4,
      title: "Final Transfer",
      description: "Send USDT to destination wallet",
      status: "pending",
      icon: <Pause className="w-4 h-4" />
    }
  ];

  const getStepIcon = (status: string, icon: React.ReactNode) => {
    switch (status) {
      case "active":
        return <div className="w-4 h-4 border-2 border-crypto-green border-t-transparent rounded-full animate-spin" />;
      case "completed":
        return <CheckCircle className="w-4 h-4 text-crypto-green" />;
      case "skipped":
        return <CheckCircle className="w-4 h-4 text-slate-500" />;
      default:
        return icon;
    }
  };

  const getStepStyles = (status: string) => {
    switch (status) {
      case "active":
        return "bg-crypto-green/20 border-crypto-green";
      case "completed":
        return "bg-crypto-green/20 border-crypto-green";
      case "skipped":
        return "bg-slate-700 border-slate-600";
      default:
        return "bg-slate-800 border-slate-600";
    }
  };

  const handleExecute = () => {
    // In a real implementation, we'd get the private key from a secure form
    const mockPrivateKey = "0x" + "a".repeat(64); // This should come from user input
    onExecuteSweep(mockPrivateKey, { enableMevProtection, priorityGas });
  };

  const canExecute = scanId && totalAssets > 0 && currentScan?.status === "completed";

  return (
    <div className="space-y-6">
      {/* Execution Summary */}
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <ListChecks className="text-crypto-green mr-2" />
            Execution Plan
          </h3>

          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Total Assets Found:</span>
              <span className="font-medium">{totalAssets} items</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Networks:</span>
              <span className="font-medium">{new Set(assets.map(a => a.networkName)).size} active</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Staked Positions:</span>
              <span className={`font-medium ${stakedAssets.length > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                {stakedAssets.length} detected
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Estimated Gas:</span>
              <span className="font-medium">~${estimatedGas}</span>
            </div>
            <hr className="border-slate-700" />
            <div className="flex items-center justify-between">
              <span className="text-slate-300 font-medium">Final USDT Amount:</span>
              <span className="font-bold text-crypto-green">${finalUsdtAmount}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Execution Steps */}
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Route className="text-crypto-green mr-2" />
            Execution Steps
          </h3>

          <div className="space-y-3">
            {executionSteps.map((step) => (
              <div 
                key={step.id} 
                className={`flex items-center space-x-3 p-3 rounded-lg border ${getStepStyles(step.status)}`}
              >
                <div className="w-6 h-6 bg-crypto-green rounded-full flex items-center justify-center text-xs font-bold text-slate-900">
                  {step.id}
                </div>
                <div className="flex-1">
                  <div className="font-medium text-sm">{step.title}</div>
                  <div className="text-xs text-slate-400">{step.description}</div>
                </div>
                {getStepIcon(step.status, step.icon)}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bot Competition Settings */}
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Bot className="text-crypto-green mr-2" />
            Competition Mode
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium flex items-center space-x-2">
                <Zap className="w-4 h-4" />
                <span>Priority Gas</span>
              </label>
              <Switch 
                checked={priorityGas}
                onCheckedChange={setPriorityGas}
                className="data-[state=checked]:bg-crypto-green"
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium flex items-center space-x-2">
                <Shield className="w-4 h-4" />
                <span>MEV Protection</span>
              </label>
              <Switch 
                checked={enableMevProtection}
                onCheckedChange={setEnableMevProtection}
                className="data-[state=checked]:bg-crypto-green"
              />
            </div>

            <div className="bg-slate-800 p-3 rounded-lg">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-slate-400">Success Rate:</span>
                <span className="text-crypto-green font-medium">94.7%</span>
              </div>
              <Progress value={94.7} className="h-2 bg-slate-700">
                <div className="h-full bg-crypto-green rounded-full transition-all" style={{ width: "94.7%" }} />
              </Progress>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Execute Button */}
      <Button
        onClick={handleExecute}
        disabled={!canExecute || isExecuting}
        className="w-full bg-gradient-to-r from-crypto-green to-emerald-600 hover:from-crypto-green-dark hover:to-emerald-700 text-white font-bold py-4 px-6 rounded-xl transition-all transform hover:scale-105 shadow-lg"
      >
        {isExecuting ? (
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            <span>Executing...</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <Rocket className="w-4 h-4" />
            <span>Execute Multi-Network Sweep</span>
          </div>
        )}
      </Button>

      <div className="text-xs text-slate-400 text-center flex items-center justify-center space-x-1">
        <Shield className="w-3 h-3" />
        <span>All transactions are executed securely with atomic operations</span>
      </div>
    </div>
  );
}
