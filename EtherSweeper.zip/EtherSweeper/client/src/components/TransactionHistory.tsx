import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { History, ExternalLink, CheckCircle, Clock, XCircle } from "lucide-react";

interface Transaction {
  id: string;
  networkName: string;
  txHash: string;
  txType: string;
  amount: string | null;
  status: string;
  createdAt: Date;
}

interface TransactionHistoryProps {
  transactions: Transaction[];
}

export function TransactionHistory({ transactions }: TransactionHistoryProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case "pending":
        return <Clock className="w-4 h-4 text-amber-400" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return (
          <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-700">
            <CheckCircle className="w-3 h-3 mr-1" />
            Success
          </Badge>
        );
      case "pending":
        return (
          <Badge variant="secondary" className="bg-amber-500/20 text-amber-400 border-amber-700">
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </Badge>
        );
      case "failed":
        return (
          <Badge variant="secondary" className="bg-red-500/20 text-red-400 border-red-700">
            <XCircle className="w-3 h-3 mr-1" />
            Failed
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary" className="bg-slate-500/20 text-slate-400 border-slate-700">
            Unknown
          </Badge>
        );
    }
  };

  const getNetworkBadge = (networkName: string) => {
    const colors: Record<string, string> = {
      "Ethereum": "bg-blue-500/20 text-blue-400 border-blue-700",
      "BNB Chain": "bg-yellow-500/20 text-yellow-400 border-yellow-700", 
      "Polygon": "bg-purple-500/20 text-purple-400 border-purple-700",
      "Arbitrum": "bg-blue-600/20 text-blue-400 border-blue-700",
      "Optimism": "bg-red-500/20 text-red-400 border-red-700",
      "Avalanche": "bg-red-600/20 text-red-400 border-red-700"
    };

    return (
      <Badge 
        variant="secondary" 
        className={colors[networkName] || "bg-slate-500/20 text-slate-400 border-slate-700"}
      >
        {networkName}
      </Badge>
    );
  };

  const formatTxHash = (hash: string) => {
    return hash.slice(0, 8) + "..." + hash.slice(-6);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(date));
  };

  const formatAmount = (amount: string | null, txType: string) => {
    if (!amount) return "-";
    
    const value = parseFloat(amount);
    if (value === 0) return "-";
    
    const formatted = `$${value.toLocaleString(undefined, { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    })}`;
    
    return txType === "sweep" ? `${formatted} USDT` : formatted;
  };

  if (transactions.length === 0) {
    return (
      <Card className="bg-slate-900 border-slate-700 mt-8">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <History className="text-crypto-green mr-2" />
            Recent Transactions
          </h3>
          
          <div className="text-center py-8 text-slate-400">
            <History className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No transactions yet</p>
            <p className="text-sm">Transaction history will appear here after execution</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900 border-slate-700 mt-8">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <History className="text-crypto-green mr-2" />
          Recent Transactions
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left py-3 px-2 text-slate-400 font-medium">Date</th>
                <th className="text-left py-3 px-2 text-slate-400 font-medium">Network</th>
                <th className="text-left py-3 px-2 text-slate-400 font-medium">Type</th>
                <th className="text-left py-3 px-2 text-slate-400 font-medium">Amount</th>
                <th className="text-left py-3 px-2 text-slate-400 font-medium">Status</th>
                <th className="text-left py-3 px-2 text-slate-400 font-medium">Tx Hash</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr key={tx.id} className="border-b border-slate-800 hover:bg-slate-800/50">
                  <td className="py-3 px-2 text-slate-300">
                    {formatDate(tx.createdAt)}
                  </td>
                  <td className="py-3 px-2">
                    {getNetworkBadge(tx.networkName)}
                  </td>
                  <td className="py-3 px-2 text-slate-300 capitalize">
                    {tx.txType}
                  </td>
                  <td className="py-3 px-2 text-crypto-green font-medium">
                    {formatAmount(tx.amount, tx.txType)}
                  </td>
                  <td className="py-3 px-2">
                    {getStatusBadge(tx.status)}
                  </td>
                  <td className="py-3 px-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-crypto-green hover:text-emerald-400 font-mono text-xs p-1 h-auto"
                    >
                      {formatTxHash(tx.txHash)}
                      <ExternalLink className="w-3 h-3 ml-1" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
