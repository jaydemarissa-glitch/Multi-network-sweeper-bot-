import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Loader2, XCircle } from "lucide-react";

interface NetworkScanStatus {
  networkName: string;
  chainId: string;
  status: string;
  assetsFound: number;
}

interface NetworkStatusProps {
  networks: NetworkScanStatus[];
  isScanning: boolean;
}

const networkIcons: Record<string, string> = {
  "Ethereum": "fab fa-ethereum",
  "BNB Chain": "fas fa-coins",
  "Polygon": "fas fa-layer-group",
  "Arbitrum": "fas fa-bolt",
  "Optimism": "fas fa-rocket",
  "Avalanche": "fas fa-mountain"
};

const networkColors: Record<string, string> = {
  "Ethereum": "bg-blue-500",
  "BNB Chain": "bg-yellow-500",
  "Polygon": "bg-purple-500",
  "Arbitrum": "bg-blue-600",
  "Optimism": "bg-red-500",
  "Avalanche": "bg-red-600"
};

export function NetworkStatus({ networks, isScanning }: NetworkStatusProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "complete":
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case "scanning":
        return <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "complete":
        return <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-700">Complete</Badge>;
      case "scanning":
        return <Badge variant="secondary" className="bg-amber-500/20 text-amber-400 border-amber-700">Scanning</Badge>;
      case "failed":
        return <Badge variant="secondary" className="bg-red-500/20 text-red-400 border-red-700">Failed</Badge>;
      default:
        return <Badge variant="secondary" className="bg-slate-500/20 text-slate-400 border-slate-700">Pending</Badge>;
    }
  };

  // Default networks if no scan data yet
  const defaultNetworks = [
    { networkName: "Ethereum", chainId: "1", status: "pending", assetsFound: 0 },
    { networkName: "BNB Chain", chainId: "56", status: "pending", assetsFound: 0 },
    { networkName: "Polygon", chainId: "137", status: "pending", assetsFound: 0 },
    { networkName: "Arbitrum", chainId: "42161", status: "pending", assetsFound: 0 },
  ];

  const displayNetworks = networks.length > 0 ? networks : defaultNetworks;

  return (
    <Card className="bg-slate-900 border-slate-700">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <i className="fas fa-network-wired text-crypto-green mr-2"></i>
          Network Scanning Status
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {displayNetworks.map((network) => (
            <div 
              key={network.chainId} 
              className="flex items-center justify-between p-3 bg-slate-800 rounded-lg border border-slate-600"
            >
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 ${networkColors[network.networkName] || 'bg-slate-500'} rounded-full flex items-center justify-center`}>
                  <i className={`${networkIcons[network.networkName] || 'fas fa-circle'} text-white text-sm`}></i>
                </div>
                <div>
                  <span className="font-medium">{network.networkName}</span>
                  {network.assetsFound > 0 && (
                    <div className="text-xs text-slate-400">
                      {network.assetsFound} assets found
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {getStatusIcon(network.status)}
                {getStatusBadge(network.status)}
              </div>
            </div>
          ))}
        </div>

        {isScanning && (
          <div className="mt-4 p-3 bg-amber-900/20 border border-amber-700 rounded-lg">
            <div className="flex items-center space-x-2 text-amber-400">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">Scanning networks for assets and staking positions...</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
