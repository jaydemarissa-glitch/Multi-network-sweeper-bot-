import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const walletScans = pgTable("wallet_scans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sourceAddress: text("source_address").notNull(),
  destinationAddress: text("destination_address").notNull(),
  status: text("status").notNull().default("pending"), // pending, scanning, executing, completed, failed
  totalValue: decimal("total_value", { precision: 18, scale: 6 }),
  estimatedGas: decimal("estimated_gas", { precision: 18, scale: 6 }),
  finalUsdtAmount: decimal("final_usdt_amount", { precision: 18, scale: 6 }),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const networkScans = pgTable("network_scans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  walletScanId: varchar("wallet_scan_id").references(() => walletScans.id),
  networkName: text("network_name").notNull(),
  chainId: text("chain_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, scanning, complete, failed
  assetsFound: jsonb("assets_found"),
  scanCompletedAt: timestamp("scan_completed_at"),
});

export const detectedAssets = pgTable("detected_assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  walletScanId: varchar("wallet_scan_id").references(() => walletScans.id),
  networkName: text("network_name").notNull(),
  tokenAddress: text("token_address"),
  tokenSymbol: text("token_symbol").notNull(),
  tokenName: text("token_name").notNull(),
  balance: decimal("balance", { precision: 18, scale: 6 }).notNull(),
  valueUsd: decimal("value_usd", { precision: 18, scale: 6 }),
  assetType: text("asset_type").notNull(), // native, erc20, staked
  stakingProtocol: text("staking_protocol"),
  isStaked: boolean("is_staked").default(false),
  unstakingRequired: boolean("unstaking_required").default(false),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  walletScanId: varchar("wallet_scan_id").references(() => walletScans.id),
  networkName: text("network_name").notNull(),
  txHash: text("tx_hash").notNull(),
  txType: text("tx_type").notNull(), // sweep, unstake, convert, transfer
  amount: decimal("amount", { precision: 18, scale: 6 }),
  status: text("status").notNull().default("pending"), // pending, confirmed, failed
  gasUsed: decimal("gas_used", { precision: 18, scale: 6 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWalletScanSchema = createInsertSchema(walletScans).pick({
  sourceAddress: true,
  destinationAddress: true,
});

export const insertNetworkScanSchema = createInsertSchema(networkScans).pick({
  walletScanId: true,
  networkName: true,
  chainId: true,
});

export const insertDetectedAssetSchema = createInsertSchema(detectedAssets).pick({
  walletScanId: true,
  networkName: true,
  tokenAddress: true,
  tokenSymbol: true,
  tokenName: true,
  balance: true,
  valueUsd: true,
  assetType: true,
  stakingProtocol: true,
  isStaked: true,
  unstakingRequired: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  walletScanId: true,
  networkName: true,
  txHash: true,
  txType: true,
  amount: true,
  gasUsed: true,
});

export type InsertWalletScan = z.infer<typeof insertWalletScanSchema>;
export type InsertNetworkScan = z.infer<typeof insertNetworkScanSchema>;
export type InsertDetectedAsset = z.infer<typeof insertDetectedAssetSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type WalletScan = typeof walletScans.$inferSelect;
export type NetworkScan = typeof networkScans.$inferSelect;
export type DetectedAsset = typeof detectedAssets.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
