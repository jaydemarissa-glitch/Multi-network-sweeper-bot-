import Web3 from 'web3';

export interface NetworkConfig {
  name: string;
  chainId: string;
  rpcUrl: string;
  nativeCurrency: string;
  explorerUrl: string;
  icon: string;
}

// Get RPC URLs with proper fallbacks
const getEthereumRpc = () => {
  if (process.env.ETHEREUM_RPC_URL) return process.env.ETHEREUM_RPC_URL;
  if (process.env.ALCHEMY_API_KEY) return `https://eth-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`;
  if (process.env.INFURA_PROJECT_ID) return `https://mainnet.infura.io/v3/${process.env.INFURA_PROJECT_ID}`;
  return "https://eth.public-rpc.com";
};

const getPolygonRpc = () => {
  if (process.env.POLYGON_RPC_URL) return process.env.POLYGON_RPC_URL;
  if (process.env.ALCHEMY_API_KEY) return `https://polygon-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`;
  if (process.env.INFURA_PROJECT_ID) return `https://polygon-mainnet.infura.io/v3/${process.env.INFURA_PROJECT_ID}`;
  return "https://polygon-rpc.com";
};

const getArbitrumRpc = () => {
  if (process.env.ARBITRUM_RPC_URL) return process.env.ARBITRUM_RPC_URL;
  if (process.env.ALCHEMY_API_KEY) return `https://arb-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`;
  if (process.env.INFURA_PROJECT_ID) return `https://arbitrum-mainnet.infura.io/v3/${process.env.INFURA_PROJECT_ID}`;
  return "https://arb1.arbitrum.io/rpc";
};

const getOptimismRpc = () => {
  if (process.env.OPTIMISM_RPC_URL) return process.env.OPTIMISM_RPC_URL;
  if (process.env.ALCHEMY_API_KEY) return `https://opt-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`;
  if (process.env.INFURA_PROJECT_ID) return `https://optimism-mainnet.infura.io/v3/${process.env.INFURA_PROJECT_ID}`;
  return "https://mainnet.optimism.io";
};

export const SUPPORTED_NETWORKS: NetworkConfig[] = [
  {
    name: "Ethereum",
    chainId: "1",
    rpcUrl: getEthereumRpc(),
    nativeCurrency: "ETH",
    explorerUrl: "https://etherscan.io",
    icon: "fab fa-ethereum"
  },
  {
    name: "BNB Chain",
    chainId: "56",
    rpcUrl: process.env.BSC_RPC_URL || "https://bsc-dataseed1.binance.org",
    nativeCurrency: "BNB",
    explorerUrl: "https://bscscan.com",
    icon: "fas fa-coins"
  },
  {
    name: "Polygon",
    chainId: "137",
    rpcUrl: getPolygonRpc(),
    nativeCurrency: "MATIC",
    explorerUrl: "https://polygonscan.com",
    icon: "fas fa-layer-group"
  },
  {
    name: "Arbitrum",
    chainId: "42161",
    rpcUrl: getArbitrumRpc(),
    nativeCurrency: "ETH",
    explorerUrl: "https://arbiscan.io",
    icon: "fas fa-bolt"
  },
  {
    name: "Optimism",
    chainId: "10",
    rpcUrl: getOptimismRpc(),
    nativeCurrency: "ETH",
    explorerUrl: "https://optimistic.etherscan.io",
    icon: "fas fa-rocket"
  },
  {
    name: "Avalanche",
    chainId: "43114",
    rpcUrl: process.env.AVALANCHE_RPC_URL || "https://api.avax.network/ext/bc/C/rpc",
    nativeCurrency: "AVAX",
    explorerUrl: "https://snowtrace.io",
    icon: "fas fa-mountain"
  },
  {
    name: "Fantom",
    chainId: "250",
    rpcUrl: process.env.FANTOM_RPC_URL || "https://rpc.fantom.network",
    nativeCurrency: "FTM",
    explorerUrl: "https://ftmscan.com",
    icon: "fas fa-ghost"
  },
  {
    name: "Base",
    chainId: "8453",
    rpcUrl: process.env.BASE_RPC_URL || "https://mainnet.base.org",
    nativeCurrency: "ETH",
    explorerUrl: "https://basescan.org",
    icon: "fas fa-cube"
  },
  {
    name: "Cronos",
    chainId: "25",
    rpcUrl: process.env.CRONOS_RPC_URL || "https://evm.cronos.org",
    nativeCurrency: "CRO",
    explorerUrl: "https://cronoscan.com",
    icon: "fas fa-clock"
  }
];

export class Web3Service {
  private web3Instances: Map<string, Web3> = new Map();

  constructor() {
    // Initialize asynchronously
    this.initializeWeb3Instances().catch(error => {
      console.error('Failed to initialize Web3 instances:', error);
    });
  }

  private async initializeWeb3Instances() {
    for (const network of SUPPORTED_NETWORKS) {
      try {
        const web3 = new Web3(network.rpcUrl);
        
        // Test connection
        await this.testConnection(web3, network);
        
        this.web3Instances.set(network.chainId, web3);
        console.log(`✅ Connected to ${network.name} (Chain ID: ${network.chainId})`);
      } catch (error) {
        console.error(`❌ Failed to connect to ${network.name}:`, error);
      }
    }
  }

  private async testConnection(web3: Web3, network: NetworkConfig): Promise<void> {
    try {
      const blockNumber = await web3.eth.getBlockNumber();
      const chainId = await web3.eth.getChainId();
      
      if (chainId.toString() !== network.chainId) {
        throw new Error(`Chain ID mismatch: expected ${network.chainId}, got ${chainId}`);
      }
      
      console.log(`${network.name} - Block: ${blockNumber}, Chain ID: ${chainId}`);
    } catch (error) {
      throw new Error(`Connection test failed: ${error}`);
    }
  }

  getWeb3Instance(chainId: string): Web3 | undefined {
    return this.web3Instances.get(chainId);
  }

  getNetworkConfig(chainId: string): NetworkConfig | undefined {
    return SUPPORTED_NETWORKS.find(network => network.chainId === chainId);
  }

  async getBalance(address: string, chainId: string): Promise<string> {
    const web3 = this.getWeb3Instance(chainId);
    if (!web3) {
      throw new Error(`Web3 instance not found for chain ${chainId}`);
    }

    try {
      const balance = await web3.eth.getBalance(address);
      return web3.utils.fromWei(balance, 'ether');
    } catch (error) {
      console.error(`Error getting balance for ${address} on chain ${chainId}:`, error);
      return "0";
    }
  }

  async getTokenBalance(address: string, tokenAddress: string, chainId: string): Promise<string> {
    const web3 = this.getWeb3Instance(chainId);
    if (!web3) {
      throw new Error(`Web3 instance not found for chain ${chainId}`);
    }

    try {
      // ERC-20 balanceOf function
      const contract = new web3.eth.Contract([
        {
          "constant": true,
          "inputs": [{"name": "_owner", "type": "address"}],
          "name": "balanceOf",
          "outputs": [{"name": "balance", "type": "uint256"}],
          "type": "function"
        },
        {
          "constant": true,
          "inputs": [],
          "name": "decimals",
          "outputs": [{"name": "", "type": "uint8"}],
          "type": "function"
        }
      ], tokenAddress);

      const [balance, decimals] = await Promise.all([
        contract.methods.balanceOf(address).call(),
        contract.methods.decimals().call()
      ]);

      const balanceValue = Array.isArray(balance) ? balance[0] : balance;
      return web3.utils.fromWei((balanceValue as any)?.toString() || "0", 'ether').substring(0, 8);
    } catch (error) {
      console.error(`Error getting token balance for ${tokenAddress}:`, error);
      return "0";
    }
  }

  async estimateGas(transaction: any, chainId: string): Promise<string> {
    const web3 = this.getWeb3Instance(chainId);
    if (!web3) {
      throw new Error(`Web3 instance not found for chain ${chainId}`);
    }

    try {
      const gasEstimate = await web3.eth.estimateGas(transaction);
      const gasPrice = await web3.eth.getGasPrice();
      const totalGas = (BigInt(gasEstimate) * BigInt(gasPrice)).toString();
      return web3.utils.fromWei(totalGas, 'ether');
    } catch (error) {
      console.error(`Error estimating gas:`, error);
      return "0.001"; // Fallback estimate
    }
  }

  async sendTransaction(privateKey: string, transaction: any, chainId: string): Promise<string> {
    const web3 = this.getWeb3Instance(chainId);
    if (!web3) {
      throw new Error(`Web3 instance not found for chain ${chainId}`);
    }

    try {
      const account = web3.eth.accounts.privateKeyToAccount(privateKey);
      const signedTx = await account.signTransaction(transaction);
      const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction!);
      return receipt.transactionHash.toString();
    } catch (error) {
      console.error(`Error sending transaction:`, error);
      throw error;
    }
  }
}

export const web3Service = new Web3Service();
