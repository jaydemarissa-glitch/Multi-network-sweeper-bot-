
import { web3Service } from './web3Service';

export interface GovernanceClaim {
  protocol: string;
  tokenSymbol: string;
  claimableAmount: string;
  claimDeadline?: Date;
  requiresAction: boolean;
  claimContract: string;
  chainId: string;
}

export interface GovernanceProtocol {
  name: string;
  symbol: string;
  chainId: string;
  claimContract: string;
  merkleDistributor?: string;
}

export class GovernanceService {
  private governanceProtocols: GovernanceProtocol[] = [
    {
      name: "Uniswap",
      symbol: "UNI",
      chainId: "1",
      claimContract: "0x090D4613473dEE047c3f2706764f49E0821D256e"
    },
    {
      name: "Compound",
      symbol: "COMP",
      chainId: "1",
      claimContract: "0xc00e94Cb662C3520282E6f5717214004A7f26888"
    },
    {
      name: "Aave",
      symbol: "AAVE",
      chainId: "1",
      claimContract: "0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9"
    },
    {
      name: "Optimism",
      symbol: "OP",
      chainId: "10",
      claimContract: "0x2223F9FE624F69Da4D8256A7bCc9104FBA7F8f75"
    },
    {
      name: "Arbitrum",
      symbol: "ARB",
      chainId: "42161",
      claimContract: "0x67a24CE4321aB3aF51c2D0a4801c3E111D88C9d9"
    },
    {
      name: "1inch",
      symbol: "1INCH",
      chainId: "1",
      claimContract: "0x111111111117dC0aa78b770fA6A738034120C302"
    },
    {
      name: "SushiSwap",
      symbol: "SUSHI",
      chainId: "1",
      claimContract: "0x6B3595068778DD592e39A122f4f5a5cF09C90fE2"
    }
  ];

  async detectGovernanceClaims(address: string): Promise<GovernanceClaim[]> {
    const claims: GovernanceClaim[] = [];

    for (const protocol of this.governanceProtocols) {
      try {
        const claim = await this.checkProtocolClaim(address, protocol);
        if (claim && parseFloat(claim.claimableAmount) > 0) {
          claims.push(claim);
        }
      } catch (error) {
        console.error(`Error checking ${protocol.name} claims:`, error);
      }
    }

    return claims;
  }

  private async checkProtocolClaim(address: string, protocol: GovernanceProtocol): Promise<GovernanceClaim | null> {
    const web3 = web3Service.getWeb3Instance(protocol.chainId);
    if (!web3) return null;

    try {
      // Mock claim detection - would integrate with actual claim contracts
      const mockClaimable = this.generateMockClaimAmount();
      
      if (mockClaimable === "0") return null;

      return {
        protocol: protocol.name,
        tokenSymbol: protocol.symbol,
        claimableAmount: mockClaimable,
        requiresAction: true,
        claimContract: protocol.claimContract,
        chainId: protocol.chainId,
        claimDeadline: this.getClaimDeadline(protocol.name)
      };
    } catch (error) {
      console.error(`Error checking ${protocol.name} claim:`, error);
      return null;
    }
  }

  async claimGovernanceToken(claim: GovernanceClaim, privateKey: string): Promise<string> {
    const web3 = web3Service.getWeb3Instance(claim.chainId);
    if (!web3) {
      throw new Error(`Web3 instance not found for chain ${claim.chainId}`);
    }

    try {
      // Mock claim transaction - would integrate with actual claim functions
      const account = web3.eth.accounts.privateKeyToAccount(privateKey);
      
      // Simulate claim transaction
      const mockTx = {
        to: claim.claimContract,
        from: account.address,
        data: "0x4e71d92d", // claim() function signature
        gas: "100000",
        gasPrice: await web3.eth.getGasPrice()
      };

      const signedTx = await account.signTransaction(mockTx);
      const txHash = "0x" + Math.random().toString(16).substr(2, 64);
      
      return txHash;
    } catch (error) {
      console.error(`Error claiming ${claim.protocol}:`, error);
      throw error;
    }
  }

  async claimAllGovernanceTokens(claims: GovernanceClaim[], privateKey: string): Promise<string[]> {
    const txHashes: string[] = [];

    // Sort by deadline (urgent first)
    const sortedClaims = claims.sort((a, b) => {
      if (!a.claimDeadline && !b.claimDeadline) return 0;
      if (!a.claimDeadline) return 1;
      if (!b.claimDeadline) return -1;
      return a.claimDeadline.getTime() - b.claimDeadline.getTime();
    });

    for (const claim of sortedClaims) {
      try {
        const txHash = await this.claimGovernanceToken(claim, privateKey);
        txHashes.push(txHash);
        await this.delay(3000); // Delay between claims
      } catch (error) {
        console.error(`Failed to claim ${claim.protocol}:`, error);
      }
    }

    return txHashes;
  }

  async estimateClaimValues(claims: GovernanceClaim[]): Promise<string> {
    let totalValue = 0;

    // Mock price data - would integrate with price feeds
    const mockPrices: Record<string, number> = {
      "UNI": 7.5,
      "COMP": 45,
      "AAVE": 85,
      "OP": 2.1,
      "ARB": 1.2,
      "1INCH": 0.4,
      "SUSHI": 1.1
    };

    for (const claim of claims) {
      const price = mockPrices[claim.tokenSymbol] || 1;
      const amount = parseFloat(claim.claimableAmount);
      totalValue += amount * price;
    }

    return totalValue.toFixed(2);
  }

  private generateMockClaimAmount(): string {
    // Simulate some addresses having claims, others not
    const hasClain = Math.random() > 0.7; // 30% chance of having claims
    if (!hasClain) return "0";
    
    // Generate random claim amount
    const amount = Math.random() * 1000 + 10; // 10-1010 tokens
    return amount.toFixed(4);
  }

  private getClaimDeadline(protocol: string): Date | undefined {
    // Some protocols have claim deadlines
    const deadlineProtocols: Record<string, number> = {
      "Optimism": 90, // 90 days from now
      "Arbitrum": 180, // 180 days from now
    };

    const days = deadlineProtocols[protocol];
    if (!days) return undefined;

    const deadline = new Date();
    deadline.setDate(deadline.getDate() + days);
    return deadline;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const governanceService = new GovernanceService();
