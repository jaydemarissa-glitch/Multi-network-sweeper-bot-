import { web3Service, SUPPORTED_NETWORKS } from './web3Service';
import { storage } from '../storage';
import { InsertDetectedAsset } from '@shared/schema';

export interface TokenInfo {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
}

// Common ERC-20 tokens by network
const COMMON_TOKENS: Record<string, TokenInfo[]> = {
  "1": [ // Ethereum
    { address: "0xA0b86a33E6Df1b4f4A6b3fF1E0f6C1d8E2f3A4B5", symbol: "USDC", name: "USD Coin", decimals: 6 },
    { address: "0xdAC17F958D2ee523a2206206994597C13D831ec7", symbol: "USDT", name: "Tether USD", decimals: 6 },
    { address: "0x6B175474E89094C44Da98b954EedeAC495271d0F", symbol: "DAI", name: "Dai Stablecoin", decimals: 18 },
    { address: "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84", symbol: "stETH", name: "Liquid staked Ether 2.0", decimals: 18 }
  ],
  "56": [ // BNB Chain
    { address: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", symbol: "USDC", name: "USD Coin", decimals: 18 },
    { address: "0x55d398326f99059fF775485246999027B3197955", symbol: "USDT", name: "Tether USD", decimals: 18 },
    { address: "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82", symbol: "CAKE", name: "PancakeSwap Token", decimals: 18 }
  ],
  "137": [ // Polygon
    { address: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174", symbol: "USDC", name: "USD Coin", decimals: 6 },
    { address: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F", symbol: "USDT", name: "Tether USD", decimals: 6 }
  ]
};

export class NetworkService {
  async scanWalletOnNetwork(address: string, chainId: string, walletScanId: string): Promise<InsertDetectedAsset[]> {
    const detectedAssets: InsertDetectedAsset[] = [];
    const network = web3Service.getNetworkConfig(chainId);
    
    if (!network) {
      throw new Error(`Network configuration not found for chain ${chainId}`);
    }

    try {
      // Scan native currency balance
      const nativeBalance = await web3Service.getBalance(address, chainId);
      if (parseFloat(nativeBalance) > 0) {
        const nativeAsset: InsertDetectedAsset = {
          walletScanId,
          networkName: network.name,
          tokenAddress: null,
          tokenSymbol: network.nativeCurrency,
          tokenName: network.nativeCurrency,
          balance: nativeBalance,
          valueUsd: null, // Would need price API
          assetType: "native",
          stakingProtocol: null,
          isStaked: false,
          unstakingRequired: false
        };
        detectedAssets.push(nativeAsset);
      }

      // Scan common ERC-20 tokens
      const tokens = COMMON_TOKENS[chainId] || [];
      for (const token of tokens) {
        try {
          const balance = await web3Service.getTokenBalance(address, token.address, chainId);
          if (parseFloat(balance) > 0) {
            const isStakedToken = token.symbol.includes('st') || token.symbol.includes('LP');
            const tokenAsset: InsertDetectedAsset = {
              walletScanId,
              networkName: network.name,
              tokenAddress: token.address,
              tokenSymbol: token.symbol,
              tokenName: token.name,
              balance: balance,
              valueUsd: null, // Would need price API
              assetType: isStakedToken ? "staked" : "erc20",
              stakingProtocol: isStakedToken ? this.detectStakingProtocol(token.symbol) : null,
              isStaked: isStakedToken,
              unstakingRequired: isStakedToken
            };
            detectedAssets.push(tokenAsset);
          }
        } catch (error) {
          console.error(`Error scanning token ${token.symbol}:`, error);
        }
      }

      return detectedAssets;
    } catch (error) {
      console.error(`Error scanning wallet on ${network.name}:`, error);
      throw error;
    }
  }

  private detectStakingProtocol(tokenSymbol: string): string | null {
    if (tokenSymbol.includes('stETH')) return 'Lido';
    if (tokenSymbol.includes('CAKE')) return 'PancakeSwap';
    if (tokenSymbol.includes('LP')) return 'UniswapV2';
    return null;
  }

  async scanAllNetworks(address: string, walletScanId: string): Promise<void> {
    const scanPromises = SUPPORTED_NETWORKS.map(async (network) => {
      try {
        // Create network scan record
        const networkScan = await storage.createNetworkScan({
          walletScanId,
          networkName: network.name,
          chainId: network.chainId
        });

        // Update status to scanning
        await storage.updateNetworkScan(networkScan.id, { status: "scanning" });

        // Perform the actual scan
        const assets = await this.scanWalletOnNetwork(address, network.chainId, walletScanId);
        
        // Save detected assets
        for (const asset of assets) {
          await storage.createDetectedAsset(asset);
        }

        // Update network scan as complete
        await storage.updateNetworkScan(networkScan.id, { 
          status: "complete",
          scanCompletedAt: new Date(),
          assetsFound: assets
        });

        return assets;
      } catch (error) {
        console.error(`Failed to scan ${network.name}:`, error);
        
        // Mark network scan as failed
        const networkScan = await storage.createNetworkScan({
          walletScanId,
          networkName: network.name,
          chainId: network.chainId
        });
        
        await storage.updateNetworkScan(networkScan.id, { status: "failed" });
        return [];
      }
    });

    await Promise.all(scanPromises);
  }

  async getNetworkScanStatus(walletScanId: string) {
    const networkScans = await storage.getNetworkScansByWalletId(walletScanId);
    return networkScans.map(scan => ({
      networkName: scan.networkName,
      chainId: scan.chainId,
      status: scan.status,
      assetsFound: scan.assetsFound ? (scan.assetsFound as any[]).length : 0
    }));
  }
}

export const networkService = new NetworkService();
