
import { web3Service } from './web3Service';
import { storage } from '../storage';

export interface FarmingPosition {
  protocol: string;
  poolName: string;
  lpTokenAddress: string;
  stakedAmount: string;
  rewardTokens: string[];
  pendingRewards: string[];
  apy: string;
  lockPeriod?: string;
  canWithdraw: boolean;
}

export interface YieldProtocol {
  name: string;
  chainId: string;
  masterChefAddress: string;
  rewardToken: string;
}

export class YieldFarmingService {
  private yieldProtocols: YieldProtocol[] = [
    {
      name: "PancakeSwap",
      chainId: "56",
      masterChefAddress: "0x73feaa1eE314F8c655E354234017bE2193C9E24E",
      rewardToken: "CAKE"
    },
    {
      name: "SushiSwap",
      chainId: "1",
      masterChefAddress: "0xc2EdaD668740f1aA35E4D8f227fB8E17dcA888Cd",
      rewardToken: "SUSHI"
    },
    {
      name: "QuickSwap",
      chainId: "137",
      masterChefAddress: "0x570d90F3b6E37C4C3fE48675F99e87c2d9DDB4B6",
      rewardToken: "QUICK"
    },
    {
      name: "TraderJoe",
      chainId: "43114",
      masterChefAddress: "0xd6a4F121CA35509aF06A0Be99093d08462f53052",
      rewardToken: "JOE"
    }
  ];

  async detectFarmingPositions(address: string, chainId: string): Promise<FarmingPosition[]> {
    const positions: FarmingPosition[] = [];
    const protocols = this.yieldProtocols.filter(p => p.chainId === chainId);

    for (const protocol of protocols) {
      try {
        const protocolPositions = await this.scanProtocolPositions(address, protocol);
        positions.push(...protocolPositions);
      } catch (error) {
        console.error(`Error scanning ${protocol.name}:`, error);
      }
    }

    return positions;
  }

  private async scanProtocolPositions(address: string, protocol: YieldProtocol): Promise<FarmingPosition[]> {
    const web3 = web3Service.getWeb3Instance(protocol.chainId);
    if (!web3) return [];

    const positions: FarmingPosition[] = [];

    try {
      // MasterChef contract ABI (simplified)
      const masterChefAbi = [
        {
          "inputs": [{"name": "_pid", "type": "uint256"}, {"name": "_user", "type": "address"}],
          "name": "userInfo",
          "outputs": [{"name": "amount", "type": "uint256"}, {"name": "rewardDebt", "type": "uint256"}],
          "type": "function"
        },
        {
          "inputs": [{"name": "_pid", "type": "uint256"}, {"name": "_user", "type": "address"}],
          "name": "pendingCake",
          "outputs": [{"name": "", "type": "uint256"}],
          "type": "function"
        },
        {
          "inputs": [],
          "name": "poolLength",
          "outputs": [{"name": "", "type": "uint256"}],
          "type": "function"
        }
      ];

      const contract = new web3.eth.Contract(masterChefAbi, protocol.masterChefAddress);

      // Get total number of pools
      const poolLength = await contract.methods.poolLength().call();
      const maxPools = Math.min(Number(poolLength), 50); // Limit to avoid timeout

      // Check each pool for user positions
      for (let pid = 0; pid < maxPools; pid++) {
        try {
          const userInfo = await contract.methods.userInfo(pid, address).call();
          const stakedAmount = Array.isArray(userInfo) ? userInfo[0] : userInfo.amount;

          if (stakedAmount && BigInt(stakedAmount.toString()) > 0) {
            const pendingRewards = await contract.methods.pendingCake(pid, address).call();
            
            const position: FarmingPosition = {
              protocol: protocol.name,
              poolName: `Pool ${pid}`,
              lpTokenAddress: `0x${pid.toString(16).padStart(40, '0')}`, // Mock LP token address
              stakedAmount: web3.utils.fromWei(stakedAmount.toString(), 'ether'),
              rewardTokens: [protocol.rewardToken],
              pendingRewards: [web3.utils.fromWei(pendingRewards.toString(), 'ether')],
              apy: this.calculateAPY(protocol.name, pid),
              canWithdraw: true
            };

            positions.push(position);
          }
        } catch (poolError) {
          // Skip individual pool errors
          continue;
        }
      }
    } catch (error) {
      console.error(`Error scanning ${protocol.name} positions:`, error);
    }

    return positions;
  }

  async withdrawFromFarm(position: FarmingPosition, privateKey: string): Promise<string> {
    const chainId = this.getChainIdForProtocol(position.protocol);
    const web3 = web3Service.getWeb3Instance(chainId);
    
    if (!web3) {
      throw new Error(`Web3 instance not found for chain ${chainId}`);
    }

    // Mock withdrawal transaction
    const txHash = "0x" + Math.random().toString(16).substr(2, 64);
    return txHash;
  }

  async harvestAllRewards(positions: FarmingPosition[], privateKey: string): Promise<string[]> {
    const txHashes: string[] = [];

    for (const position of positions) {
      try {
        const txHash = await this.harvestRewards(position, privateKey);
        txHashes.push(txHash);
        await this.delay(3000); // Delay between harvests
      } catch (error) {
        console.error(`Failed to harvest from ${position.protocol}:`, error);
      }
    }

    return txHashes;
  }

  private async harvestRewards(position: FarmingPosition, privateKey: string): Promise<string> {
    // Mock harvest transaction
    const txHash = "0x" + Math.random().toString(16).substr(2, 64);
    return txHash;
  }

  private calculateAPY(protocol: string, poolId: number): string {
    // Mock APY calculation based on protocol and pool
    const baseAPY = Math.random() * 100 + 20; // 20-120%
    return baseAPY.toFixed(2) + "%";
  }

  private getChainIdForProtocol(protocol: string): string {
    const protocolChains: Record<string, string> = {
      "PancakeSwap": "56",
      "SushiSwap": "1",
      "QuickSwap": "137",
      "TraderJoe": "43114",
      "SpookySwap": "250"
    };
    return protocolChains[protocol] || "1";
  }

  async getAllFarmingPositions(address: string): Promise<FarmingPosition[]> {
    const allPositions: FarmingPosition[] = [];
    const uniqueChains = [...new Set(this.yieldProtocols.map(p => p.chainId))];

    for (const chainId of uniqueChains) {
      try {
        const positions = await this.detectFarmingPositions(address, chainId);
        allPositions.push(...positions);
      } catch (error) {
        console.error(`Error scanning farming positions on chain ${chainId}:`, error);
      }
    }

    return allPositions;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const yieldFarmingService = new YieldFarmingService();
