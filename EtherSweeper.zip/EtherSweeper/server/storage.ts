import { 
  type WalletScan, 
  type InsertWalletScan,
  type NetworkScan,
  type InsertNetworkScan,
  type DetectedAsset,
  type InsertDetectedAsset,
  type Transaction,
  type InsertTransaction
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Wallet Scans
  createWalletScan(scan: InsertWalletScan): Promise<WalletScan>;
  getWalletScan(id: string): Promise<WalletScan | undefined>;
  updateWalletScan(id: string, updates: Partial<WalletScan>): Promise<WalletScan>;
  getWalletScans(): Promise<WalletScan[]>;

  // Network Scans
  createNetworkScan(scan: InsertNetworkScan): Promise<NetworkScan>;
  getNetworkScansByWalletId(walletScanId: string): Promise<NetworkScan[]>;
  updateNetworkScan(id: string, updates: Partial<NetworkScan>): Promise<NetworkScan>;

  // Detected Assets
  createDetectedAsset(asset: InsertDetectedAsset): Promise<DetectedAsset>;
  getAssetsByWalletId(walletScanId: string): Promise<DetectedAsset[]>;
  updateDetectedAsset(id: string, updates: Partial<DetectedAsset>): Promise<DetectedAsset>;

  // Transactions
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionsByWalletId(walletScanId: string): Promise<Transaction[]>;
  getRecentTransactions(limit?: number): Promise<Transaction[]>;
  updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction>;
}

export class MemStorage implements IStorage {
  private walletScans: Map<string, WalletScan>;
  private networkScans: Map<string, NetworkScan>;
  private detectedAssets: Map<string, DetectedAsset>;
  private transactions: Map<string, Transaction>;

  constructor() {
    this.walletScans = new Map();
    this.networkScans = new Map();
    this.detectedAssets = new Map();
    this.transactions = new Map();
  }

  async createWalletScan(insertScan: InsertWalletScan): Promise<WalletScan> {
    const id = randomUUID();
    const scan: WalletScan = {
      ...insertScan,
      id,
      status: "pending",
      totalValue: null,
      estimatedGas: null,
      finalUsdtAmount: null,
      createdAt: new Date(),
      completedAt: null,
    };
    this.walletScans.set(id, scan);
    return scan;
  }

  async getWalletScan(id: string): Promise<WalletScan | undefined> {
    return this.walletScans.get(id);
  }

  async updateWalletScan(id: string, updates: Partial<WalletScan>): Promise<WalletScan> {
    const existing = this.walletScans.get(id);
    if (!existing) {
      throw new Error("Wallet scan not found");
    }
    const updated = { ...existing, ...updates };
    this.walletScans.set(id, updated);
    return updated;
  }

  async getWalletScans(): Promise<WalletScan[]> {
    return Array.from(this.walletScans.values()).sort((a, b) => 
      (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );
  }

  async createNetworkScan(insertScan: InsertNetworkScan): Promise<NetworkScan> {
    const id = randomUUID();
    const scan: NetworkScan = {
      id,
      walletScanId: insertScan.walletScanId || null,
      networkName: insertScan.networkName,
      chainId: insertScan.chainId,
      status: "pending",
      assetsFound: null,
      scanCompletedAt: null,
    };
    this.networkScans.set(id, scan);
    return scan;
  }

  async getNetworkScansByWalletId(walletScanId: string): Promise<NetworkScan[]> {
    return Array.from(this.networkScans.values()).filter(
      scan => scan.walletScanId === walletScanId
    );
  }

  async updateNetworkScan(id: string, updates: Partial<NetworkScan>): Promise<NetworkScan> {
    const existing = this.networkScans.get(id);
    if (!existing) {
      throw new Error("Network scan not found");
    }
    const updated = { ...existing, ...updates };
    this.networkScans.set(id, updated);
    return updated;
  }

  async createDetectedAsset(insertAsset: InsertDetectedAsset): Promise<DetectedAsset> {
    const id = randomUUID();
    const asset: DetectedAsset = {
      id,
      walletScanId: insertAsset.walletScanId || null,
      networkName: insertAsset.networkName,
      tokenAddress: insertAsset.tokenAddress || null,
      tokenSymbol: insertAsset.tokenSymbol,
      tokenName: insertAsset.tokenName,
      balance: insertAsset.balance,
      valueUsd: insertAsset.valueUsd || null,
      assetType: insertAsset.assetType,
      stakingProtocol: insertAsset.stakingProtocol || null,
      isStaked: insertAsset.isStaked || false,
      unstakingRequired: insertAsset.unstakingRequired || false,
    };
    this.detectedAssets.set(id, asset);
    return asset;
  }

  async getAssetsByWalletId(walletScanId: string): Promise<DetectedAsset[]> {
    return Array.from(this.detectedAssets.values()).filter(
      asset => asset.walletScanId === walletScanId
    );
  }

  async updateDetectedAsset(id: string, updates: Partial<DetectedAsset>): Promise<DetectedAsset> {
    const existing = this.detectedAssets.get(id);
    if (!existing) {
      throw new Error("Detected asset not found");
    }
    const updated = { ...existing, ...updates };
    this.detectedAssets.set(id, updated);
    return updated;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      id,
      walletScanId: insertTransaction.walletScanId || null,
      networkName: insertTransaction.networkName,
      txHash: insertTransaction.txHash,
      txType: insertTransaction.txType,
      amount: insertTransaction.amount || null,
      gasUsed: insertTransaction.gasUsed || null,
      status: "pending",
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getTransactionsByWalletId(walletScanId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      tx => tx.walletScanId === walletScanId
    ).sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async getRecentTransactions(limit: number = 10): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction> {
    const existing = this.transactions.get(id);
    if (!existing) {
      throw new Error("Transaction not found");
    }
    const updated = { ...existing, ...updates };
    this.transactions.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
