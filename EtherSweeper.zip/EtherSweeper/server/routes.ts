import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { networkService } from "./services/networkService";
import { stakingService } from "./services/stakingService";
import { dexService } from "./services/dexService";
import { bridgeService } from './services/bridgeService';
import { yieldFarmingService } from './services/yieldFarmingService';
import { governanceService } from './services/governanceService';
import { nftService } from './services/nftService';
import { aiOptimizationService } from './services/aiOptimizationService';
import { web3Service, SUPPORTED_NETWORKS } from "./services/web3Service";
import { insertWalletScanSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {

  // Create wallet scan
  app.post("/api/wallet-scans", async (req, res) => {
    try {
      const validatedData = insertWalletScanSchema.parse(req.body);
      const walletScan = await storage.createWalletScan(validatedData);

      // Start scanning in background
      networkService.scanAllNetworks(validatedData.sourceAddress, walletScan.id)
        .then(async () => {
          // Update scan status to completed
          const assets = await storage.getAssetsByWalletId(walletScan.id);
          const totalValue = assets.reduce((sum, asset) => 
            sum + (parseFloat(asset.valueUsd || "0")), 0
          );

          await storage.updateWalletScan(walletScan.id, {
            status: "completed",
            totalValue: totalValue.toString(),
            completedAt: new Date()
          });
        })
        .catch(async (error) => {
          console.error("Scan failed:", error);
          await storage.updateWalletScan(walletScan.id, {
            status: "failed"
          });
        });

      res.json(walletScan);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Get wallet scan details
  app.get("/api/wallet-scans/:id", async (req, res) => {
    try {
      const walletScan = await storage.getWalletScan(req.params.id);
      if (!walletScan) {
        return res.status(404).json({ message: "Wallet scan not found" });
      }
      res.json(walletScan);
    } catch (error) {
      res.status(500).json({ message: "Failed to get wallet scan" });
    }
  });

  // Get network scan status
  app.get("/api/wallet-scans/:id/networks", async (req, res) => {
    try {
      const networkStatus = await networkService.getNetworkScanStatus(req.params.id);
      res.json(networkStatus);
    } catch (error) {
      res.status(500).json({ message: "Failed to get network status" });
    }
  });

  // Get detected assets
  app.get("/api/wallet-scans/:id/assets", async (req, res) => {
    try {
      const assets = await storage.getAssetsByWalletId(req.params.id);
      res.json(assets);
    } catch (error) {
      res.status(500).json({ message: "Failed to get assets" });
    }
  });

  // Get unstaking plan
  app.get("/api/wallet-scans/:id/unstaking-plan", async (req, res) => {
    try {
      const stakedAssets = await stakingService.detectStakedPositions(req.params.id);
      const unstakingPlan = await stakingService.createUnstakingPlan(stakedAssets);
      res.json(unstakingPlan);
    } catch (error) {
      res.status(500).json({ message: "Failed to create unstaking plan" });
    }
  });

  // Execute wallet sweep
  app.post("/api/wallet-scans/:id/execute", async (req, res) => {
    try {
      const { privateKey, enableMevProtection = true, priorityGas = true } = req.body;

      if (!privateKey) {
        return res.status(400).json({ message: "Private key required" });
      }

      const walletScan = await storage.getWalletScan(req.params.id);
      if (!walletScan) {
        return res.status(404).json({ message: "Wallet scan not found" });
      }

      // Update status to executing
      await storage.updateWalletScan(req.params.id, { status: "executing" });

      // Get all assets
      const assets = await storage.getAssetsByWalletId(req.params.id);
      const stakedAssets = assets.filter(asset => asset.isStaked);
      const liquidAssets = assets.filter(asset => !asset.isStaked);

      const executionPlan = {
        unstakeTransactions: [],
        swapTransactions: [],
        transferTransactions: []
      };

      // Step 1: Unstake staked positions
      if (stakedAssets.length > 0) {
        const unstakingPlans = await stakingService.createUnstakingPlan(stakedAssets);
        for (const plan of unstakingPlans) {
          const txHashes = await stakingService.executeUnstaking(plan, privateKey);
          (executionPlan.unstakeTransactions as string[]).push(...txHashes);
        }
      }

      // Step 2: Convert all assets to USDT
      const allAssets = [...liquidAssets, ...stakedAssets];
      const swapTxHashes = await dexService.batchSwapToUSDT(allAssets, privateKey);
      (executionPlan.swapTransactions as string[]).push(...swapTxHashes);

      // Step 3: Transfer final USDT to destination
      // This would be implemented with actual Web3 transaction

      res.json({
        message: "Execution started",
        executionPlan,
        estimatedCompletion: "5-10 minutes"
      });

    } catch (error) {
      console.error("Execution failed:", error);
      await storage.updateWalletScan(req.params.id, { status: "failed" });
      res.status(500).json({ message: "Execution failed" });
    }
  });

  // Get supported networks
  app.get("/api/networks", async (req, res) => {
    res.json(SUPPORTED_NETWORKS);
  });

  // Get recent transactions
  app.get("/api/transactions/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const transactions = await storage.getRecentTransactions(limit);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get transactions" });
    }
  });

  // Get transactions for wallet scan
  app.get("/api/wallet-scans/:id/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByWalletId(req.params.id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get transactions" });
    }
  });

  // Get execution progress
  app.get("/api/wallet-scans/:id/progress", async (req, res) => {
    try {
      const walletScan = await storage.getWalletScan(req.params.id);
      const unstakingProgress = await stakingService.getUnstakingProgress(req.params.id);
      const networkStatus = await networkService.getNetworkScanStatus(req.params.id);

      res.json({
        walletScan,
        unstakingProgress,
        networkStatus
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get progress" });
    }
  });

  // Execute sweep
  app.post("/api/execute-sweep", async (req, res) => {
    try {
      const { walletScanId, privateKey, destinationAddress } = req.body;

      if (!walletScanId || !privateKey || !destinationAddress) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Get detected assets
      const assets = await storage.getDetectedAssets(walletScanId);

      // Execute batch swap to USDT
      const swapTxs = await dexService.batchSwapToUSDT(assets, privateKey);

      // Create execution record
      const execution = await storage.createExecution({
        walletScanId,
        destinationAddress,
        status: "pending"
      });

      res.json({ 
        success: true, 
        executionId: execution.id,
        transactionHashes: swapTxs 
      });
    } catch (error) {
      console.error('Execute sweep error:', error);
      res.status(500).json({ error: "Failed to execute sweep" });
    }
  });

  // Bridge routes
  app.get("/api/bridge/quote/:walletScanId", async (req, res) => {
    try {
      const { walletScanId } = req.params;
      const { targetChain = "1" } = req.query;

      const assets = await storage.getDetectedAssets(walletScanId);
      const quotes = [];

      for (const asset of assets) {
        const quote = await bridgeService.getOptimalBridgeRoute(asset, targetChain as string);
        quotes.push(quote);
      }

      res.json(quotes);
    } catch (error) {
      console.error('Bridge quote error:', error);
      res.status(500).json({ error: "Failed to get bridge quotes" });
    }
  });

  app.post("/api/bridge/execute", async (req, res) => {
    try {
      const { walletScanId, privateKey } = req.body;
      const assets = await storage.getDetectedAssets(walletScanId);
      const txHashes = await bridgeService.consolidateToMainnet(assets, privateKey);

      res.json({ success: true, transactionHashes: txHashes });
    } catch (error) {
      console.error('Bridge execution error:', error);
      res.status(500).json({ error: "Failed to execute bridge" });
    }
  });

  // Yield farming routes
  app.get("/api/yield-farming/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const positions = await yieldFarmingService.getAllFarmingPositions(address);
      res.json(positions);
    } catch (error) {
      console.error('Yield farming detection error:', error);
      res.status(500).json({ error: "Failed to detect farming positions" });
    }
  });

  app.post("/api/yield-farming/harvest", async (req, res) => {
    try {
      const { positions, privateKey } = req.body;
      const txHashes = await yieldFarmingService.harvestAllRewards(positions, privateKey);
      res.json({ success: true, transactionHashes: txHashes });
    } catch (error) {
      console.error('Harvest error:', error);
      res.status(500).json({ error: "Failed to harvest rewards" });
    }
  });

  // Governance routes
  app.get("/api/governance/claims/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const claims = await governanceService.detectGovernanceClaims(address);
      const totalValue = await governanceService.estimateClaimValues(claims);

      res.json({ claims, totalValue });
    } catch (error) {
      console.error('Governance claims error:', error);
      res.status(500).json({ error: "Failed to detect governance claims" });
    }
  });

  app.post("/api/governance/claim-all", async (req, res) => {
    try {
      const { claims, privateKey } = req.body;
      const txHashes = await governanceService.claimAllGovernanceTokens(claims, privateKey);
      res.json({ success: true, transactionHashes: txHashes });
    } catch (error) {
      console.error('Claim all error:', error);
      res.status(500).json({ error: "Failed to claim governance tokens" });
    }
  });

  // NFT routes
  app.get("/api/nfts/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const nfts = await nftService.getAllNFTs(address);
      const floorPrices = await nftService.getFloorPrices(nfts);
      const liquidationValue = await nftService.estimateLiquidationValue(nfts);

      res.json({ nfts, floorPrices, liquidationValue });
    } catch (error) {
      console.error('NFT detection error:', error);
      res.status(500).json({ error: "Failed to detect NFTs" });
    }
  });

  app.post("/api/nfts/quick-sell", async (req, res) => {
    try {
      const { nfts, privateKey, discountPercent = 10 } = req.body;
      const listings = await nftService.createQuickSaleListings(nfts, privateKey, discountPercent);
      res.json({ success: true, listings });
    } catch (error) {
      console.error('NFT quick sell error:', error);
      res.status(500).json({ error: "Failed to create NFT listings" });
    }
  });

  // AI optimization routes
  app.get("/api/ai/market-conditions/:chainId", async (req, res) => {
    try {
      const { chainId } = req.params;
      const conditions = await aiOptimizationService.analyzeMarketConditions(chainId);
      res.json(conditions);
    } catch (error) {
      console.error('Market conditions error:', error);
      res.status(500).json({ error: "Failed to analyze market conditions" });
    }
  });

  app.post("/api/ai/arbitrage", async (req, res) => {
    try {
      const { walletScanId } = req.body;
      const assets = await storage.getDetectedAssets(walletScanId);
      const opportunities = await aiOptimizationService.detectArbitrageOpportunities(assets);
      res.json(opportunities);
    } catch (error) {
      console.error('Arbitrage detection error:', error);
      res.status(500).json({ error: "Failed to detect arbitrage opportunities" });
    }
  });

  app.post("/api/ai/optimize-timing", async (req, res) => {
    try {
      const { walletScanId, operations } = req.body;
      const assets = await storage.getDetectedAssets(walletScanId);
      const timings = await aiOptimizationService.optimizeExecutionTiming(assets, operations);
      const plan = await aiOptimizationService.generateExecutionPlan(assets);

      res.json({ timings, executionPlan: plan });
    } catch (error) {
      console.error('Timing optimization error:', error);
      res.status(500).json({ error: "Failed to optimize timing" });
    }
  });

  app.get("/api/ai/gas-prediction/:chainId", async (req, res) => {
    try {
      const { chainId } = req.params;
      const { hours = "24" } = req.query;
      const prediction = await aiOptimizationService.predictGasPrices(chainId, parseInt(hours as string));
      res.json(prediction);
    } catch (error) {
      console.error('Gas prediction error:', error);
      res.status(500).json({ error: "Failed to predict gas prices" });
    }
  });

  // Blockchain health check endpoint
  app.get("/api/blockchain/health", async (req, res) => {
    try {
      const healthStatus = {
        timestamp: new Date().toISOString(),
        networks: [] as any[]
      };

      for (const network of SUPPORTED_NETWORKS) {
        const web3 = web3Service.getWeb3Instance(network.chainId);
        if (web3) {
          try {
            const blockNumber = await web3.eth.getBlockNumber();
            const chainId = await web3.eth.getChainId();
            
            healthStatus.networks.push({
              name: network.name,
              chainId: network.chainId,
              status: "connected",
              blockNumber: blockNumber.toString(),
              actualChainId: chainId.toString(),
              rpcUrl: network.rpcUrl.includes("infura") ? "Infura" : 
                      network.rpcUrl.includes("alchemy") ? "Alchemy" : "Public"
            });
          } catch (error) {
            healthStatus.networks.push({
              name: network.name,
              chainId: network.chainId,
              status: "error",
              error: (error as Error).message
            });
          }
        } else {
          healthStatus.networks.push({
            name: network.name,
            chainId: network.chainId,
            status: "not_initialized"
          });
        }
      }

      res.json(healthStatus);
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to check blockchain health",
        details: (error as Error).message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}