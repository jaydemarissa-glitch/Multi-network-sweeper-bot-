# Multi-Chain Wallet Sweeper Application

## Overview

This is a comprehensive multi-chain wallet sweeping application built with React, Express, and TypeScript. The system enables users to scan multiple blockchain networks for assets in source wallets and automatically transfer them to a destination wallet. It supports major blockchain networks including Ethereum, BNB Chain, Polygon, Arbitrum, and Optimism, with capabilities for handling both native tokens and ERC-20 assets, including staked positions that require unstaking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and data fetching
- **UI Framework**: Custom component library built on Radix UI primitives with Tailwind CSS
- **Styling**: Tailwind CSS with custom CSS variables for theming, featuring a dark crypto-themed design
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Framework**: Express.js with TypeScript running in ES module mode
- **Database**: PostgreSQL with Drizzle ORM for type-safe database interactions
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Storage Layer**: Abstracted storage interface with in-memory fallback for development
- **API Design**: RESTful API with structured error handling and request logging

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon Database with connection pooling
- **ORM**: Drizzle ORM providing type-safe database operations and migrations
- **Schema Management**: Centralized schema definitions in TypeScript with automatic validation
- **Migration System**: Drizzle Kit for database schema migrations

### Key Data Models
- **Wallet Scans**: Track scanning operations across multiple networks
- **Network Scans**: Individual network scanning status and results
- **Detected Assets**: Found tokens with value calculations and staking status
- **Transactions**: Execution history for sweeping operations

### Web3 Integration
- **Multi-Chain Support**: Configurable support for major EVM-compatible networks
- **RPC Management**: Environment-based RPC endpoint configuration with fallbacks
- **Token Detection**: Automated scanning for native tokens and common ERC-20 tokens
- **Staking Protocol Detection**: Support for major staking protocols like Lido and PancakeSwap

### Security Architecture
- **Input Validation**: Comprehensive validation using Zod schemas for all user inputs
- **Private Key Handling**: Client-side private key management with security warnings
- **Address Validation**: Ethereum address format validation and checksumming
- **MEV Protection**: Optional MEV protection mechanisms for transaction execution

### Service Layer Architecture
- **Network Service**: Handles multi-chain asset scanning and balance retrieval
- **Staking Service**: Detects and manages staked positions requiring unstaking
- **DEX Service**: Integrates with DEX aggregators for optimal swap routing
- **Web3 Service**: Provides blockchain interaction utilities and RPC management

## External Dependencies

### Core Infrastructure
- **Neon Database**: Serverless PostgreSQL database hosting
- **Vite**: Frontend build tool and development server
- **Node.js**: Runtime environment with ES modules support

### Blockchain Integration
- **Web3.js**: Ethereum and EVM blockchain interactions
- **RPC Providers**: Infura, Alchemy, and public RPC endpoints for blockchain connectivity
- **DEX Aggregators**: Integration points for 1inch, Paraswap for optimal swap routing

### UI and Styling
- **Radix UI**: Headless UI component primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography
- **Font Awesome**: Additional icon set for crypto-specific icons

### Development Tools
- **TypeScript**: Static type checking across the full stack
- **ESLint/Prettier**: Code formatting and linting
- **Drizzle Kit**: Database migration and introspection tools
- **React Hook Form**: Form state management with validation

### Third-Party Services
- **Price Feeds**: CoinGecko or similar for asset price data
- **Blockchain Explorers**: Etherscan, BSCScan, PolygonScan for transaction verification
- **Staking Protocols**: Lido, PancakeSwap, and other DeFi protocol APIs

### Deployment Dependencies
- **Replit**: Development and hosting environment
- **PostCSS**: CSS processing with autoprefixer
- **esbuild**: Fast JavaScript bundling for production builds